function newstart() {

    var color = {
        red: "color:#d83128;font-size:11px;",
        yellow: "color:#ea991b;font-size:11px;",
        green: "color:#93ba2f;font-size:11px;",
        blue: "color:#4da4e0;font-size:11px;"
    };

            console.log(
                "               %c__  \
                \n%c    __ _ %c  __ _ %c|`|  \
                \n%c   / _` |%c / _` |%c| |   \
                \n%c      | |%c| (_| |%c| |__,\
                \n%c    __, | %c\\__,_|%c\\____|\
                \n%c   |___/\
                \n %cWarehouse Management System is %cJ%cA%cL.\n", 
                color.red,
                color.green, color.blue, color.red, 
                color.green, color.blue, color.red, 
                color.green, color.blue, color.red, 
                color.green, color.blue, color.red, 
                color.green, 
                color.yellow, color.green, color.blue, color.red
            );
         
        console.log("\x3e \x3e \x3e https://www.human.or.kr/\n")
                }

newstart();




//              __  
//  __ _   __ _ |`|     
// / _` | / _` || |   
//    | || (_| || |__,
//  __, | \__,_| \____|
// |___/
