package com.spring.lim;

import lombok.Data;

@Data
public class ItMngNewDTO {

	String img;
	String pname;
	String sct;
	String pnum;
	String wzone;
	String bct;
	String psize;
	String punit;
	String pday;
	int pamount;
	
}
