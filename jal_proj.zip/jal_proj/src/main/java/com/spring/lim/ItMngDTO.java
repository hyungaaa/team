package com.spring.lim;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class ItMngDTO {
	String pname;
	String pnum;
	String wzone;
	String scid;
	String psize;
	String punit;
	String pday;
	String img;
	String sct;
	String bcid;
}
