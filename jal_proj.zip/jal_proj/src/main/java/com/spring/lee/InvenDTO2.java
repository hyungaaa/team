package com.spring.lee;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class InvenDTO2 {
	String ire;
	int icnt;
	String plot;
}
